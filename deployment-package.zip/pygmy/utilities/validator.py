def is_valid_url(url):
    return True


def is_valid_email(email):
    return True
