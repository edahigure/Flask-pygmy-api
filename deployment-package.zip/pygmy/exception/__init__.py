from pygmy.exception.invalidurl import URLNotFound
from pygmy.exception.auth import URLAuthFailed
from pygmy.exception.error import PygmyExcpetion
