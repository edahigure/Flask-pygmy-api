from pygmy.database.base import BaseDatabase


class MySQLDatabase(BaseDatabase):
    pass
