from pygmy.helpers.link_helper import next_short_code
